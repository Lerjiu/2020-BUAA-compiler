public class WordTable {
    public static void addWord() {

    }
}
